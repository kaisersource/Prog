/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Server {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try {
            
            
            ServerSocket ss=new ServerSocket(3003);
            
            while(true){
                Socket s=ss.accept();
                Thread t = new ThreadT(s);
                t.start();
            }
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
