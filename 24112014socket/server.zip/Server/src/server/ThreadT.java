/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BACKSLASHZERO
 */
public class ThreadT extends Thread {

    Socket s;

    public ThreadT(Socket s) {
        
        this.s = s;
    }
    
public void run(){
    String str;
    int a=0;
try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            while((str=in.readLine())!=null){
                if(str=="BYE")
                    break;
                else{
                 System.out.println(str);
                 a++;
                }
            
            }   
                System.out.println(a);
                in.close();
                s.close();
                
        } catch (IOException ex) {
            Logger.getLogger(ThreadT.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    

}
