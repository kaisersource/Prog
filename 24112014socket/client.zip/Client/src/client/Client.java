/*
Il client genera casualmente un intero N.
Il client invia poi al server N stringhe: “stringa1”, “stringa2”,… “stringaN”.
La trasmissione è terminata inviando la stringa “BYE”.
Ogni volta che un client si disconnette il server scrive sullo schermo il numero di stringhe
ricevute in totale da tutti i client fino a quel momento.
Se necessario, si gestiscano le problematiche di sincronizzazione.
 */
package client;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ip="localhost";
        int porta=3003;
        Socket s;
        String str;
        int n;
        
        try {
            s = new Socket(ip,porta);
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            n=(int)(Math.random()*10);
            for(int i=0;i<n;i++){
                out.println("Stringa"+i);
            }
            out.println("BYE");
            
            s.close();
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
