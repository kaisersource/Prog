/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;
/*
 Si definisca una applicazione client server basata su socket. Il server deve poter
 rispondere contemporaneamente a più client.abstract Il client genera casualmente un intero N
 Il client invia poi al server N interi positivi casuali minori di 100.
 Il server genera casualmente un intero M (lo stesso valore è usato per tutti i client).
 Ogni volta che un client si disconnette, il server scrive sullo schermo la media dei valori
 più grandi di M ricevuti in totale da tutti i client fino a quel momento.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            int port = 3003;
            String ip = "127.0.0.1";
            Socket s = new Socket(ip, port);

            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            for (int i = 0; i < (int) (1 + Math.random() * 10); i++) {
                out.println((int) (Math.random() * 100));
            }
            out.println(-1);
            out.close();
            s.close();

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
