/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author BACKSLASHZERO
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ThreadServer extends Thread {

    int M;
    Socket s;

    public ThreadServer(Socket s, int M) {
        this.M = M;
        this.s = s;
    }

    @Override
    public void run() {
        String str;
        int x, somma = 0, count = 0;

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            while ((str = br.readLine()) != null) {
                if (str.equals("-1")) {
                    break;
                } else {
                    if ((x = Integer.parseInt(str)) > M) {
                        somma = somma + x;
                        count++;
                    }

                }
            }
            System.out.println("La media dei valori maggiori di M è " + somma / count);
            br.close();
            s.close();

        } catch (IOException ex) {
            Logger.getLogger(ThreadServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
